# Sistem Pembayaran Bulanan — DALAM PAGAR KANDANGAN

Aplikasi internal berbasis Flask + SQLite. Data santri awal sengaja kosong.

## Fitur
- Login untuk petugas TU/bendahara
- Tambah, ubah, cari, nonaktifkan data santri
- Pencatatan pembayaran manual per bulan tagihan
- Kwitansi dengan nomor unik, siap dicetak atau disimpan sebagai PDF melalui dialog cetak browser
- Rekap pemasukan bulanan, daftar tunggakan, ekspor laporan CSV
- Perlindungan CSRF, password hash, session cookie HttpOnly/SameSite

## Kebutuhan
- Python 3.10 atau lebih baru
- Browser modern
- Komputer lokal/server internal pondok

## Instalasi (Windows)
1. Ekstrak ZIP ke folder, lalu buka Command Prompt/PowerShell di folder `dalpa_pembayaran`.
2. Buat virtual environment:
   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```
   Jika PowerShell memblokir aktivasi, jalankan `.\.venv\Scripts\python.exe -m pip install -r requirements.txt` dan gunakan `.venv\Scripts\python.exe` untuk perintah selanjutnya.
3. Pasang dependensi:
   ```powershell
   python -m pip install -r requirements.txt
   ```
4. Atur kata sandi administrator melalui environment (contoh PowerShell; ganti kata sandinya):
   ```powershell
   $env:SECRET_KEY = "buat-string-acak-panjang-yang-rahasia"
   $env:ADMIN_USER = "bendahara"
   $env:ADMIN_PASSWORD = "GantiDenganKataSandiPanjang12Karakter!"
   ```
5. Buat database dan akun:
   ```powershell
   flask --app app init-db
   ```
6. Jalankan website:
   ```powershell
   flask --app app run
   ```
7. Buka `http://127.0.0.1:5000` di browser. Login menggunakan username dan password yang tadi disetel.

## Instalasi (macOS/Linux)
```bash
cd dalpa_pembayaran
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export SECRET_KEY='isi-dengan-string-acak-panjang'
export ADMIN_USER='bendahara'
export ADMIN_PASSWORD='GantiDenganKataSandiPanjang12Karakter!'
flask --app app init-db
flask --app app run
```
Lalu buka `http://127.0.0.1:5000`.

## Catatan penting
- Jalankan di komputer TU terlebih dahulu. Server development Flask hanya untuk uji coba, bukan deployment internet.
- Database `pembayaran.db` dibuat otomatis di folder aplikasi setelah perintah `init-db`.
- Backup rutin dengan menyalin `pembayaran.db` setelah aplikasi dihentikan, simpan salinan terenkripsi di lokasi terpisah, dan uji pemulihan backup.
- Untuk penggunaan bersama melalui jaringan pondok/internet, gunakan server produksi (misalnya Waitress/Gunicorn di belakang HTTPS), firewall, secret key kuat, akun unik tiap petugas, dan kebijakan backup. Set `COOKIE_SECURE=1` jika HTTPS aktif.
- Jangan bagikan akun antarpetugas. Saat ini aplikasi hanya menyediakan satu akun awal; akun tambahan dapat ditambahkan kemudian melalui pengelolaan pengguna.
- Tunggakan dihitung untuk bulan yang dipilih: biaya bulanan dikurangi jumlah transaksi pada bulan itu, minimum nol. Transaksi lebih besar dari biaya tidak ditampilkan sebagai tunggakan.
- Sistem ini tidak terhubung ke bank atau payment gateway. Bukti transfer tetap diperiksa manual oleh petugas sebelum transaksi dicatat.
- CSV dapat dibuka dengan Excel. Kwitansi dicetak melalui tombol “Cetak / Simpan PDF”.
- Sebelum digunakan secara resmi, uji alur, kebijakan nominal/tagihan, format kwitansi, dan lakukan backup.

## Struktur database
- `user`: username, password hash, role, status aktif.
- `student`: nomor induk unik, nama, kelas/kamar, wali, biaya bulanan, status aktif.
- `payment`: nomor kwitansi unik, ID santri, bulan tagihan, nominal, tanggal bayar, metode, catatan, petugas pencatat.
