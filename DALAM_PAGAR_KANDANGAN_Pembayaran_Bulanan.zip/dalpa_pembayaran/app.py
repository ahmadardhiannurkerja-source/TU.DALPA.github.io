import os
from datetime import date, datetime
from functools import wraps
from io import BytesIO

from flask import Flask, render_template, request, redirect, url_for, flash, session, make_response, abort
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "GANTI-DENGAN-SECRET-KEY-ACAK-SEBELUM-PRODUKSI")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(os.path.abspath(os.path.dirname(__file__)), "pembayaran.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"
db = SQLAlchemy(app)
csrf = CSRFProtect(app)

INSTITUTION = "DALAM PAGAR KANDANGAN"

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), nullable=False, default="TU/Bendahara")
    active = db.Column(db.Boolean, default=True, nullable=False)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_no = db.Column(db.String(40), unique=True, nullable=False)
    full_name = db.Column(db.String(160), nullable=False)
    class_name = db.Column(db.String(80), default="")
    guardian_name = db.Column(db.String(160), default="")
    monthly_fee = db.Column(db.Integer, nullable=False, default=0)
    active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    receipt_no = db.Column(db.String(50), unique=True, nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    billing_month = db.Column(db.String(7), nullable=False)  # YYYY-MM
    amount = db.Column(db.Integer, nullable=False)
    paid_at = db.Column(db.Date, nullable=False, default=date.today)
    method = db.Column(db.String(50), nullable=False, default="Tunai")
    note = db.Column(db.String(500), default="")
    recorded_by = db.Column(db.String(80), nullable=False)
    student = db.relationship("Student", backref=db.backref("payments", lazy=True))

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        user = db.session.get(User, session["user_id"])
        if not user or not user.active:
            session.clear()
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def rupiah(value):
    return "Rp {:,}".format(int(value or 0)).replace(",", ".")
app.jinja_env.filters["rupiah"] = rupiah

@app.context_processor
def common_context():
    return {"institution": INSTITUTION, "current_user": session.get("username")}

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username, active=True).first()
        if user and check_password_hash(user.password_hash, password):
            session.clear()
            session["user_id"] = user.id
            session["username"] = user.username
            return redirect(url_for("dashboard"))
        flash("Nama pengguna atau kata sandi tidak cocok.", "error")
    return render_template("login.html")

@app.post("/logout")
@login_required
def logout():
    session.clear()
    flash("Anda telah keluar.", "success")
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    students_count = Student.query.filter_by(active=True).count()
    paid = db.session.query(func.coalesce(func.sum(Payment.amount), 0)).filter_by(billing_month=month).scalar()
    paid_students = db.session.query(Payment.student_id).filter_by(billing_month=month).distinct().count()
    outstanding = 0
    for student in Student.query.filter_by(active=True).all():
        paid_for_month = db.session.query(func.coalesce(func.sum(Payment.amount), 0)).filter_by(student_id=student.id, billing_month=month).scalar()
        outstanding += max(student.monthly_fee - paid_for_month, 0)
    recent = Payment.query.order_by(Payment.id.desc()).limit(8).all()
    return render_template("dashboard.html", month=month, students_count=students_count, paid=paid,
                           paid_students=paid_students, outstanding=outstanding, recent=recent)

@app.route("/santri")
@login_required
def students():
    q = request.args.get("q", "").strip()
    query = Student.query
    if q:
        query = query.filter((Student.full_name.ilike(f"%{q}%")) | (Student.student_no.ilike(f"%{q}%")))
    return render_template("students.html", students=query.order_by(Student.full_name).all(), q=q)

@app.route("/santri/tambah", methods=["GET", "POST"])
@login_required
def add_student():
    if request.method == "POST":
        student_no = request.form.get("student_no", "").strip()
        full_name = request.form.get("full_name", "").strip()
        class_name = request.form.get("class_name", "").strip()
        guardian_name = request.form.get("guardian_name", "").strip()
        try:
            monthly_fee = int(request.form.get("monthly_fee", "0"))
        except ValueError:
            monthly_fee = -1
        if not student_no or not full_name or monthly_fee < 0:
            flash("Nomor induk, nama santri, dan nominal bulanan yang valid wajib diisi.", "error")
        elif Student.query.filter_by(student_no=student_no).first():
            flash("Nomor induk tersebut sudah terdaftar.", "error")
        else:
            db.session.add(Student(student_no=student_no, full_name=full_name, class_name=class_name,
                                   guardian_name=guardian_name, monthly_fee=monthly_fee))
            db.session.commit()
            flash("Data santri berhasil ditambahkan.", "success")
            return redirect(url_for("students"))
    return render_template("student_form.html", student=None)

@app.route("/santri/<int:student_id>/ubah", methods=["GET", "POST"])
@login_required
def edit_student(student_id):
    student = db.get_or_404(Student, student_id)
    if request.method == "POST":
        student_no = request.form.get("student_no", "").strip()
        full_name = request.form.get("full_name", "").strip()
        try:
            monthly_fee = int(request.form.get("monthly_fee", "0"))
        except ValueError:
            monthly_fee = -1
        duplicate = Student.query.filter(Student.student_no == student_no, Student.id != student.id).first()
        if not student_no or not full_name or monthly_fee < 0 or duplicate:
            flash("Periksa kembali data. Nomor induk harus unik dan nominal tidak boleh negatif.", "error")
        else:
            student.student_no = student_no
            student.full_name = full_name
            student.class_name = request.form.get("class_name", "").strip()
            student.guardian_name = request.form.get("guardian_name", "").strip()
            student.monthly_fee = monthly_fee
            student.active = request.form.get("active") == "on"
            db.session.commit()
            flash("Data santri berhasil diperbarui.", "success")
            return redirect(url_for("students"))
    return render_template("student_form.html", student=student)

@app.post("/santri/<int:student_id>/hapus")
@login_required
def delete_student(student_id):
    student = db.get_or_404(Student, student_id)
    if student.payments:
        flash("Santri memiliki riwayat pembayaran. Nonaktifkan melalui menu ubah agar riwayat tetap aman.", "error")
    else:
        db.session.delete(student)
        db.session.commit()
        flash("Data santri dihapus.", "success")
    return redirect(url_for("students"))

@app.route("/pembayaran", methods=["GET", "POST"])
@login_required
def payments():
    if request.method == "POST":
        student_id = request.form.get("student_id", type=int)
        billing_month = request.form.get("billing_month", "")
        amount = request.form.get("amount", type=int)
        paid_at_str = request.form.get("paid_at", "")
        method = request.form.get("method", "Tunai")
        note = request.form.get("note", "").strip()
        student = db.session.get(Student, student_id) if student_id else None
        try:
            paid_at = datetime.strptime(paid_at_str, "%Y-%m-%d").date()
            datetime.strptime(billing_month, "%Y-%m")
        except ValueError:
            paid_at = None
        if not student or not billing_month or not paid_at or amount is None or amount <= 0:
            flash("Isi semua data pembayaran dengan benar. Nominal harus lebih dari nol.", "error")
        else:
            receipt_no = "DPK-" + datetime.now().strftime("%Y%m%d%H%M%S%f")[-17:]
            payment = Payment(receipt_no=receipt_no, student_id=student.id, billing_month=billing_month,
                              amount=amount, paid_at=paid_at, method=method, note=note,
                              recorded_by=session.get("username", "TU"))
            db.session.add(payment)
            db.session.commit()
            flash("Pembayaran dicatat. Kwitansi siap dicetak.", "success")
            return redirect(url_for("receipt", payment_id=payment.id))
    selected_month = request.args.get("month", date.today().strftime("%Y-%m"))
    records = Payment.query.filter_by(billing_month=selected_month).order_by(Payment.paid_at.desc()).all()
    return render_template("payments.html", students=Student.query.filter_by(active=True).order_by(Student.full_name).all(),
                           records=records, month=selected_month, today=date.today().isoformat())

@app.route("/kwitansi/<int:payment_id>")
@login_required
def receipt(payment_id):
    payment = db.get_or_404(Payment, payment_id)
    return render_template("receipt.html", payment=payment)

@app.route("/tunggakan")
@login_required
def arrears():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    rows = []
    for student in Student.query.filter_by(active=True).order_by(Student.full_name).all():
        paid = db.session.query(func.coalesce(func.sum(Payment.amount), 0)).filter_by(student_id=student.id, billing_month=month).scalar()
        due = max(student.monthly_fee - paid, 0)
        rows.append({"student": student, "paid": paid, "due": due})
    return render_template("arrears.html", rows=rows, month=month, total_due=sum(x["due"] for x in rows))

@app.route("/laporan")
@login_required
def reports():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    records = Payment.query.filter_by(billing_month=month).order_by(Payment.paid_at.desc()).all()
    total = sum(p.amount for p in records)
    return render_template("reports.html", records=records, month=month, total=total)

@app.route("/laporan.csv")
@login_required
def report_csv():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    records = Payment.query.filter_by(billing_month=month).order_by(Payment.paid_at.desc()).all()
    lines = ["Nomor Kwitansi,Tanggal Bayar,Nomor Induk,Nama Santri,Bulan Tagihan,Nominal,Metode,Petugas"]
    for p in records:
        vals = [p.receipt_no, p.paid_at.isoformat(), p.student.student_no, p.student.full_name,
                p.billing_month, str(p.amount), p.method, p.recorded_by]
        lines.append(",".join('"' + str(v).replace('"', '""') + '"' for v in vals))
    response = make_response("\ufeff" + "\n".join(lines))
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = f"attachment; filename=laporan-{month}.csv"
    return response

@app.cli.command("init-db")
def init_db():
    """Buat tabel dan akun awal dari variabel lingkungan ADMIN_USER dan ADMIN_PASSWORD."""
    db.create_all()
    username = os.environ.get("ADMIN_USER", "bendahara")
    password = os.environ.get("ADMIN_PASSWORD")
    if not password:
        print("Tabel dibuat. Set ADMIN_PASSWORD lalu jalankan perintah init-admin untuk membuat akun.")
        return
    if not User.query.filter_by(username=username).first():
        db.session.add(User(username=username, password_hash=generate_password_hash(password)))
        db.session.commit()
        print(f"Akun awal '{username}' dibuat.")
    else:
        print("Akun pengguna sudah ada; tidak diubah.")

@app.cli.command("init-admin")
def init_admin():
    db.create_all()
    username = os.environ.get("ADMIN_USER", "bendahara")
    password = os.environ.get("ADMIN_PASSWORD")
    if not password or len(password) < 12:
        raise SystemExit("Atur ADMIN_PASSWORD minimal 12 karakter pada environment sebelum menjalankan.")
    user = User.query.filter_by(username=username).first()
    if user:
        raise SystemExit("Username sudah ada. Gunakan username lain atau kelola akun langsung di database.")
    db.session.add(User(username=username, password_hash=generate_password_hash(password)))
    db.session.commit()
    print(f"Akun '{username}' berhasil dibuat.")

if __name__ == "__main__":
    app.run(debug=False)
